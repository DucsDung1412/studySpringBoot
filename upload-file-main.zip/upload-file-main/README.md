# upload-file
It will store images into database and fetch data from database
